package Interfaces;

import Model.Pokemones.Pokemon;

public interface IBatalla {

    public double ataqueNormal();

}
