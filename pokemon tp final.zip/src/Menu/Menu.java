package Menu;

import Model.Entrenador.Entrenador;
import Model.Pokemones.Pokemon;

public class Menu {

    //cada vez que un pokemon ataca a otro se aprovecha este texto

    public static String mostrarResultadoAtaque(Pokemon atacante, Pokemon defensor, double efectividad, int damage) {
        StringBuilder sb = new StringBuilder();
        sb.append(atacante.getNombre()).append(" atacó a ").append(defensor.getNombre()).append("\n")
                .append("Tipo atacante: ").append(atacante.getTipo()).append(" → Tipo defensor: ").append(defensor.getTipo()).append("\n")
                .append("Efectividad: x").append(efectividad).append("\n")
                .append("Daño causado: ").append(damage).append("\n")
                .append("❤ Vida restante de ").append(defensor.getNombre()).append(": ").append(defensor.getVidaRestante()).append("\n");

        return sb.toString();
    }



    public static void menuPrincipal(){
        System.out.println("\n===== MENÚ PRINCIPAL =====");
        System.out.println("1. Equipos");
        System.out.println("2. Pokédex");
        System.out.println("3. Batallar");
        System.out.println("0. Salir");
        System.out.print("Elegí una opción: ");
    }

    public static void menuEquipos(){
        System.out.println("\n===== MENÚ EQUIPOS =====");
        System.out.println("1. Agregar peleador");
        System.out.println("2. Ver peleadores y sus Pokémon");
        System.out.println("3. Importar ambos equipos desde JSON ");
        System.out.println("0. Volver");
        System.out.print("Opción: ");
    }

    public static void menuMochila(){
        System.out.println("\n--- Menú Mochila ---");
        System.out.println("1. Rellenar / completar automáticamente");
        System.out.println("2. Rellenar manualmente");
        System.out.println("3. Ver mochila");
        System.out.println("4. Eliminar Pokémon");
        System.out.println("5. Guardar peleador y volver");
        System.out.print("Opción: ");
    } //Menu mochila existe dentro de menuEquipos



    public static void menuBatalla() {
        System.out.println("\n===== MENÚ BATALLA =====");
        System.out.println("1. Iniciar batalla");
        System.out.println("2. Guardar batalla previa en JSON");
        System.out.println("0. Volver");
        System.out.print("Opción: ");



    }

    //Opciones internas una vez dentro de la batalla

   public static  String opcionesBatalla(Entrenador entrenadorAtacante, Pokemon  pokemonAtacante, Pokemon pokemonDefensor)
   {
       StringBuilder sb = new StringBuilder();
       sb.append("\nTurno de ")
               .append(entrenadorAtacante.getNombre()).append(" ")
               .append(entrenadorAtacante.getApellido()).append(" (")
               .append(pokemonAtacante.getNombre()).append(") (૭ ｡•̀ ᵕ •́｡ )૭\n")
               .append("Vida de tu Pokémon: ").append(pokemonAtacante.getVidaRestante()).append("\n")
               .append("Vida del oponente: ").append(pokemonDefensor.getVidaRestante()).append("\n \n")
               .append("4. Atacar\n")
               .append("5. Cambiar Pokémon (Pierde el turno)\n")
               .append("Elegí una opción: ");

       return sb.toString();

   }








}


