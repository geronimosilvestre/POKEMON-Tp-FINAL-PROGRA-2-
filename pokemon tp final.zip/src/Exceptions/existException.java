package Exceptions;

public class existException extends Exception {
    public existException(String message) {
        super(message);
    }
}
