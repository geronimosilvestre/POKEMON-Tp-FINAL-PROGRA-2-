package Exceptions;

public class teamsStillAliveException extends Exception {
    public teamsStillAliveException(String message) {
        super(message);
    }
}
