package Exceptions;

public class notPokemonFoundException extends Exception {
    public notPokemonFoundException(String message) {
        super(message);
    }
}
