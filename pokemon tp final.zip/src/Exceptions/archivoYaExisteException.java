package Exceptions;

public class archivoYaExisteException extends Exception {
    public archivoYaExisteException(String message) {
        super(message);
    }
}
