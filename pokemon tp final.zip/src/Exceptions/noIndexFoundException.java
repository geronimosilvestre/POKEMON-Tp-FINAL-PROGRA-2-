package Exceptions;

public class noIndexFoundException extends Exception {
  public noIndexFoundException(String message) {
    super(message);
  }
}
