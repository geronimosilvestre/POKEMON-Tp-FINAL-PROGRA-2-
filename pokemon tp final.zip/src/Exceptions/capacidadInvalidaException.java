package Exceptions;

public class capacidadInvalidaException extends Exception {
    public capacidadInvalidaException(String message) {
        super(message);
    }
}
