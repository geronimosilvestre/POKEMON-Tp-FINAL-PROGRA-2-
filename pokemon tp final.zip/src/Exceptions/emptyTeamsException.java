package Exceptions;

public class emptyTeamsException extends Exception {
    public emptyTeamsException(String message) {
        super(message);
    }
}
