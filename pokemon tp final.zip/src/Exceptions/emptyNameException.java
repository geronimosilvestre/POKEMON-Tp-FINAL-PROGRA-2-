package Exceptions;

public class emptyNameException extends Exception {
    public emptyNameException(String message) {
        super(message);
    }
}
